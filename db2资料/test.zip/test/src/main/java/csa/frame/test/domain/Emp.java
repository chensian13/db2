package csa.frame.test.domain;

import csa.frame.db2.annotation.Field;
import csa.frame.db2.annotation.Key;

public class Emp {
	@Key("emp_id")
	private int id;
	@Field("emp_name")
	private String  emp_name;
	@Field("salary")
	private String  salary;
	@Field("emp_code")
	private String  emp_code;
	@Field("dept_code")
	private String  dept_code;
	@Field("job_code")
	private String  job_code;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getEmp_code() {
		return emp_code;
	}
	public void setEmp_code(String emp_code) {
		this.emp_code = emp_code;
	}
	public String getDept_code() {
		return dept_code;
	}
	public void setDept_code(String dept_code) {
		this.dept_code = dept_code;
	}
	public String getJob_code() {
		return job_code;
	}
	public void setJob_code(String job_code) {
		this.job_code = job_code;
	}
	@Override
	public String toString() {
		return "Emp [id=" + id + ", emp_name=" + emp_name + ", salary=" + salary + ", emp_code=" + emp_code
				+ ", dept_code=" + dept_code + ", job_code=" + job_code + "]";
	}
	
	
	
	
	
}
