package csa.frame.test;

import java.io.IOException;
import java.sql.Connection;

import org.junit.Test;

import csa.frame.db2.config.Config;
import csa.frame.db2.template.Connect;

public class ConnectTest {
	
	@Test
	public void test01() throws IOException{
		Config config=new Config();
		System.out.println(config.getConfigProperties());
	}

	@Test
	public void test02(){
		Connection conn=Connect.getConnection();
		System.out.println(conn);
	}
}
