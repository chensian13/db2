package csa.frame.test.dao;

import java.util.List;

import csa.frame.db2.annotation.SQL;
import csa.frame.db2.constant.ExecuteType;
import csa.frame.test.domain.Dept;

public interface DeptDao {
	
	@SQL(value="select * from dept",resultType=Dept.class,type=ExecuteType.SELECT)
	List<Dept> selectAll();
	
	@SQL(value="select * from dept where dept_code=?",resultType=Dept.class,type=ExecuteType.SELECT)
	Dept selectByCode(String code);

}
