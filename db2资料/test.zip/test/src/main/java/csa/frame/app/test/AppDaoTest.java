package csa.frame.app.test;

import org.junit.Test;

import csa.frame.db2.app.ConnectionStore;
import csa.frame.db2.app.SqlSession;
import csa.frame.db2.app.SqlSessionFactory;
import csa.frame.test.dao.EmpDao;
import csa.frame.test.domain.Emp;

public class AppDaoTest {
	private SqlSession session=SqlSessionFactory.openSqlSession();
	private EmpDao empDao=session.getDao(EmpDao.class);
	
	
	@Test
	public void test01(){
		for(Emp emp:empDao.selectAll()){
			System.out.println(emp);
		}
	}
	
	@Test
	public void test02(){
		ConnectionStore.registerConnection();
		for(Emp emp:empDao.selectByName("%��%")){
			System.out.println(emp);
		}
		ConnectionStore.closeConnection();
	}

}
