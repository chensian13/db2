package csa.frame.test;

import java.util.List;

import org.junit.Test;

import csa.frame.db2.app.ConnectionStore;
import csa.frame.db2.config.DaoConfig;
import csa.frame.test.dao.DeptDao;
import csa.frame.test.dao.EmpDao;
import csa.frame.test.domain.Dept;
import csa.frame.test.domain.Emp;

public class DaoTest {
	private EmpDao empDao=DaoConfig.newInstance(EmpDao.class);
	private DeptDao deptDao=DaoConfig.newInstance( DeptDao.class);
	
	@Test
	public void test01(){
		System.out.println(empDao);
	}

	
	@Test
	public void test02(){
		ConnectionStore.registerConnection();
		List<Emp> list=empDao.selectAll();
		for (Emp emp : list) {
			System.out.println(emp);
		}
		ConnectionStore.closeConnection();
	}
	
	@Test
	public void test03(){
		ConnectionStore.registerConnection();
		List<Emp> list=empDao.selectByName("%��%");
		for (Emp emp : list) {
			System.out.println(emp);
		}
		ConnectionStore.closeConnection();
	}

	@Test
	public void test04(){
		ConnectionStore.registerConnection();
		System.out.println(empDao.selectByCode("%yu%"));
		ConnectionStore.closeConnection();
	}
	
	@Test
	public void test05(){
		ConnectionStore.registerConnection();
		for(Dept dept:deptDao.selectAll()){
			System.out.println(dept);
		}
		ConnectionStore.closeConnection();
	}
	
	@Test
	public void test06(){
		ConnectionStore.registerConnection();
		System.out.println(deptDao.selectByCode("yanfa"));
		ConnectionStore.closeConnection();
	}

}
