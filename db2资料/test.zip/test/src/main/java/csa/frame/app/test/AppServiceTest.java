package csa.frame.app.test;

import org.junit.Test;

import csa.frame.db2.app.SqlSession;
import csa.frame.test.service.EmpService;
import csa.frame.test.service.EmpServiceImpl;

public class AppServiceTest {
	 private EmpService empService=SqlSession.getService(EmpServiceImpl.class);
	 
	 @Test
	 public void Test01(){
		 empService.selectByName("��");
	 }
	 
	 @Test
	 public void Test02(){
		 empService.insertEmp();
	 }
	 
	 @Test
	 public void Test03(){
		 empService.selectByName2("��");
	 }

}
