package csa.frame.test.service;

import java.sql.ResultSet;
import java.util.ArrayList;

import csa.frame.db2.app.SqlSession;
import csa.frame.db2.app.SqlSessionFactory;
import csa.frame.db2.app.WrapResultListener;
import csa.frame.db2.template.Beanhandler;
import csa.frame.test.dao.EmpDao;
import csa.frame.test.domain.Emp;

public class EmpServiceImpl implements EmpService{
	private SqlSession session=SqlSessionFactory.openSqlSession();
	private EmpDao empDao=session.getDao(EmpDao.class);
	
	
	public void selectByName(String name){
		System.out.println(empDao.selectByName("%"+name+"%"));
		System.out.println("********************************************");
		for(Emp emp:empDao.selectAll()){
			System.out.println(emp);
		}
	}
	
	public void selectByName2(String name){
		System.out.println(empDao.selectByName("%"+name+"%",new WrapResultListener<Emp>() {
			
			public void wrapResult(Beanhandler<Emp> beanhandler, ResultSet rs) throws Exception {
				beanhandler.setList(new ArrayList<Emp>());
				while(rs.next()){
					beanhandler.getList().add(beanhandler.wrapOne(Emp.class, rs));
				}
			}
		}));
	}


	public void insertEmp() {
		empDao.delByCode("chenbo");
		int i=1/0;
		System.out.println("������"+empDao.addOne("�²�", "5000", "chenbo","kaifa", "java"));
		System.out.println(empDao.selectByCode("chenbo"));
	}
	
	

}
