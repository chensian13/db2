package csa.frame.test.service;

import csa.frame.db2.annotation.Transaction;
import csa.frame.db2.constant.IsolateLevel;

public interface EmpService {
	
	
	public void selectByName(String name);
	
	@Transaction(isolate=IsolateLevel.REPEATABLE)
	public void insertEmp();
	
	@Transaction(isolate=IsolateLevel.REPEATABLE)
	public void selectByName2(String name);

}
