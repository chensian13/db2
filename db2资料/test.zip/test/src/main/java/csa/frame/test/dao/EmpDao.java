package csa.frame.test.dao;

import java.util.List;
import java.util.Map;

import csa.frame.db2.annotation.SQL;
import csa.frame.db2.app.WrapResultListener;
import csa.frame.db2.constant.ExecuteType;
import csa.frame.test.domain.Emp;

public interface EmpDao {
	
	@SQL(type=ExecuteType.SELECT,value="select * from emp",resultType=Emp.class)
	public List<Emp> selectAll();
	
	@SQL(type=ExecuteType.SELECT,value="select * from emp where emp_name like ?",resultType=Emp.class)
	public List<Emp> selectByName(String name);
	
	@SQL(type=ExecuteType.SELECT,value="select * from emp where emp_name like ?",resultType=Emp.class)
	public List<Emp> selectByName(String name, WrapResultListener listener);
	
	@SQL(type=ExecuteType.SELECT,value="select * from emp where emp_code like ?",resultType=Map.class)
	public Map selectByCode(String name);
	
	@SQL(type=ExecuteType.INSERT,value="insert into emp(emp_name,salary,emp_code,dept_code,job_code) values(?,?,?,?,?)",resultType=long.class)
	public long addOne(String name,String salary,String emp_code,String dept_code,String jon_code);

	@SQL(type=ExecuteType.DELETE,value="delete from emp where emp_code=?")
	public int delByCode(String code);
}
