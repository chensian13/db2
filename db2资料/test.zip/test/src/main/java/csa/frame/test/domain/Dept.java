package csa.frame.test.domain;

import csa.frame.db2.annotation.Field;
import csa.frame.db2.annotation.Key;

public class Dept {
	@Key("dept_id")
	private int id;
	@Field("dept_name")
	private String dept_name;
	@Field("dept_code")
	private String dept_code;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDept_name() {
		return dept_name;
	}
	public void setDept_name(String dept_name) {
		this.dept_name = dept_name;
	}
	public String getDept_code() {
		return dept_code;
	}
	public void setDept_code(String dept_code) {
		this.dept_code = dept_code;
	}
	@Override
	public String toString() {
		return "Dept [id=" + id + ", dept_name=" + dept_name + ", dept_code=" + dept_code + "]";
	}
	
	

}
